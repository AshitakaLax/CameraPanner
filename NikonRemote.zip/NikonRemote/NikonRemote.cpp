/*
 * NikonRemote
 *
 * This is an evil Arduino library that uses inline assembly to generate an IR
 * signal capable of triggering a Nikon SLR camera.
 *
 * By Matt Mets, October, 2008.
 * Release into the public domain
 *
 * Adapted from San Bergman's 'ML-L1 / ML-L3 IR remote control replacement'
 * http://www.sbprojects.com/projects/nikon/index.htm
 *
 * Note: This is an incomplete implementation.  It requires the output LED to
 *       be on pin 12.
 */

#include "WProgram.h"
#include "NikonRemote.h"

NikonRemote::NikonRemote(unsigned int port)
{
  pinMode(port, OUTPUT);
  _port = port;
}
 
 
void NikonRemote::Snap()
{
// Definitions:
// r16: port ON value
// r17: port OFF value
// r18: burst delay counter
// r19: burst counter
// r20: end delay counter
// r21: port mask
 
// 0x03: Port B input register
// 0x05: Port B output register
 
  asm volatile (
 
"\n\t cli"              // Disable interrupts
 
"\n\t push r16"         // Save context
"\n\t push r17"
"\n\t push r18"
"\n\t push r19"
"\n\t push r20"
"\n\t push r21"
 
"\n\t in   r16, 0x03"   // Calculate on and off port values
"\n\t ori  r16, 0x10"
"\n\t in   r17, 0x03"
 
"\n\t rjmp COMMAND"     // Jump to the command routine
 
"\nNEXTPULSE:"
"\n\t ldi r18, 68"      // Count to 9 for one low pulse
"\nSENDBURST:"          // Low period delay loop
"\n\t dec r18"
"\n\t brne SENDBURST"
"\n\t nop"
"\n\t out 0x05, r21"    // Set the output to mask
"\n\t ldi r18, 68"      // Count to 9 for one high pulse
"\nBURSTLOOP:"
 
 
"\n\t dec r18"
"\n\t brne BURSTLOOP"
"\n\t out 0x05, r17"    // Set the output low
"\n\t dec r19"          // Determine if another burst should be performed.
"\n\t brne NEXTPULSE"
"\n\t ret"
 
"\nCOMMAND:"
 
// 2000us on
"\n\t ldi r18, 65"      // initial pulse = 65
"\n\t ldi r19, 76"      // count = 76
"\n\t mov r21, r16"     // Mask on
"\n\t rcall SENDBURST"
 
// 28ms off
"\n\t ldi r18, 65"      // initial pulse = 65
"\n\t ldi r19, 250"     // count = 250
"\n\t mov r21, r17"     // Mask off
"\n\t rcall SENDBURST"
"\n\t ldi r18, 65"      // initial pulse = 65
"\n\t ldi r19, 250"     // count = 250
"\n\t mov r21, r17"     // Mask off
"\n\t rcall SENDBURST"
"\n\t ldi r18, 65"      // initial pulse = 65
"\n\t ldi r19, 250"     // count = 250
"\n\t mov r21, r17"     // Mask off
"\n\t rcall SENDBURST"
"\n\t ldi r18, 65"      // initial pulse = 65
"\n\t ldi r19, 250"     // count = 250
"\n\t mov r21, r17"     // Mask off
"\n\t rcall SENDBURST"
"\n\t ldi r18, 65"      // initial pulse = 65
"\n\t ldi r19, 64"      // count = 64
"\n\t mov r21, r17"     // Mask off
"\n\t rcall SENDBURST"
 
// 400us on
"\n\t ldi r18, 65"      // initial pulse = 65
"\n\t ldi r19, 15"      // count = 15
"\n\t mov r21, r16"     // Mask on
"\n\t rcall SENDBURST"
 
// 1580us off
"\n\t ldi r18, 65"      // initial pulse = 65
"\n\t ldi r19, 60"      // count = 60
"\n\t mov r21, r17"     // Mask off
"\n\t rcall SENDBURST"
 
// 400us on
"\n\t ldi r18, 65"      // initial pulse = 65
"\n\t ldi r19, 15"      // count = 15
"\n\t mov r21, r16"     // Mask on
"\n\t rcall SENDBURST"
 
// 3580us off
"\n\t ldi r18, 65"      // initial pulse = 65
"\n\t ldi r19, 136"     // count = 136
"\n\t mov r21, r17"     // Mask off
"\n\t rcall SENDBURST"
 
// 400us on
"\n\t ldi r18, 65"      // initial pulse = 65
"\n\t ldi r19, 15"      // count = 15
"\n\t mov r21, r16"     // Mask on
"\n\t rcall SENDBURST"
 
"\n\t pop  r21"         // Restore Context
"\n\t pop  r20"
"\n\t pop  r19"
"\n\t pop  r18"
"\n\t pop  r17"
"\n\t pop  r16"
 
"\n\t sei"              // Enable interrupts
"\n\t"
  );
}
