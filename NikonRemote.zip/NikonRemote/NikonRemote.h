/*
 * NikonRemote
 *
 * This is an evil Arduino library that uses inline assembly to generate an IR
 * signal capable of triggering a Nikon SLR camera.
 *
 * By Matt Mets, October, 2008.
 * Release into the public domain
 */

#ifndef NikonRemote_h
#define NikonRemote_h

#include "WProgram.h"

class NikonRemote {
  public:
    NikonRemote(unsigned int port);
 
    void Snap();
 
  private:
    unsigned int _port;
};

#endif
